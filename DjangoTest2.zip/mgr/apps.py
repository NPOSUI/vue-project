from django.apps import AppConfig


class MgrConfig(AppConfig):
    name = 'mgr'
