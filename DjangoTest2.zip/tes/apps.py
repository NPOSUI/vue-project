from django.apps import AppConfig


class TesConfig(AppConfig):
    name = 'tes'
